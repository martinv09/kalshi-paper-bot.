#!/usr/bin/env python3
"""Kalshi DEMO public-market scanner + LOCAL simulated paper-trading ledger.
No authenticated API calls, no Kalshi orders, no production host, no AI API keys.
Python 3.10+ stdlib only. This is an educational momentum hypothesis, NOT a model of fair value.
"""
import argparse
import datetime as dt
import json
import os
import pathlib
import tempfile
import time
import urllib.parse
import urllib.request
from decimal import Decimal, InvalidOperation

BASE = 'https://demo-api.kalshi.co/trade-api/v2'  # fixed, no production override
D = Decimal
STATE_FILE = pathlib.Path(os.getenv('PAPER_STATE', 'paper_state.json'))
MAX_TRADE = D('2.00')
MAX_GROSS = D('10.00')
MAX_DAILY_LOSS = D('5.00')
MAX_POSITIONS = 3
MAX_SPREAD = D('0.08')
FEE_PER_SIDE = D('0.01')  # synthetic safety buffer, NOT official Kalshi fee calculation
MIN_MOMENTUM = D('0.03')
MAX_PRICE = D('0.80')
MAX_AGE_S = 45 * 60


def now():
    return dt.datetime.now(dt.timezone.utc)


def val(x):
    try:
        v = D(str(x))
        return v if v.is_finite() else None
    except (InvalidOperation, TypeError, ValueError):
        return None


def get_markets(pages=3):
    markets, cursor = [], None
    for _ in range(pages):
        params = {'status': 'open', 'limit': 200}
        if cursor:
            params['cursor'] = cursor
        url = BASE + '/markets?' + urllib.parse.urlencode(params)
        req = urllib.request.Request(url, headers={'User-Agent':'DemoPaperBot/1.0','Accept':'application/json'})
        with urllib.request.urlopen(req, timeout=15) as resp:
            payload = json.load(resp)
        if not isinstance(payload.get('markets'), list):
            raise ValueError('Invalid Kalshi markets response')
        markets.extend(payload['markets'])
        cursor = payload.get('cursor')
        if not cursor:
            break
        time.sleep(0.35)
    return markets


def quote(m):
    """Require current dollar-string fields; old cent fields deliberately unsupported."""
    bid, ask = val(m.get('yes_bid_dollars')), val(m.get('yes_ask_dollars'))
    if bid is None or ask is None or not (D('0') < bid <= ask < D('1')):
        return None
    if ask - bid > MAX_SPREAD:
        return None
    return bid, ask


def initial():
    return {'starting_cash': '100.00', 'cash': '100.00', 'day': now().date().isoformat(),
            'day_start_equity': '100.00', 'halted': False, 'positions': {}, 'history': {}, 'trades': []}


def load_state():
    if not STATE_FILE.exists():
        return initial()
    with STATE_FILE.open() as f:
        s = json.load(f)
    if not all(k in s for k in ('cash','day','day_start_equity','positions','history','trades','halted')):
        raise ValueError('Malformed state file; refusing to trade')
    return s


def save_state(s):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.paper-', dir=str(STATE_FILE.parent))
    try:
        with os.fdopen(fd,'w') as f:
            json.dump(s, f, indent=2)
            f.flush(); os.fsync(f.fileno())
        os.replace(name, STATE_FILE)
    finally:
        if os.path.exists(name): os.unlink(name)


def equity(s, quotes):
    cash = D(s['cash'])
    for ticker, p in s['positions'].items():
        bid = quotes.get(ticker, (None,None))[0]
        # Unknown / stale quotes get conservative ZERO liquidation value; never mark at entry.
        cash += max(D('0'), bid - FEE_PER_SIDE) if bid is not None else D('0')
    return cash


def gross(s):
    return sum((D(p['cost']) for p in s['positions'].values()), D('0'))


def run_cycle(s, markets, at=None):
    at = at or now()
    today = at.date().isoformat()
    quotes = {}
    titles = {}
    for m in markets:
        ticker = m.get('ticker')
        if not isinstance(ticker,str) or not ticker:
            continue
        q = quote(m)
        if q is not None:
            quotes[ticker] = q
            titles[ticker] = m.get('title', ticker)
    # If any held quote missing, do not place fresh orders, and retain halt until operator reviews.
    missing = set(s['positions']) - set(quotes)
    if missing:
        s['halted'] = True
        print('HALTED: Missing valid quote(s) for positions:', ', '.join(sorted(missing)))
    cur_equity = equity(s, quotes)
    if s['day'] != today:
        s['day'] = today
        s['day_start_equity'] = str(cur_equity)
        # Keep any previous halt. Only explicit reset clears it.
    if cur_equity <= D(s['day_start_equity']) - MAX_DAILY_LOSS:
        s['halted'] = True
        print('HALTED: Daily drawdown limit reached')
    if pathlib.Path('STOP').exists():
        s['halted'] = True
        print('HALTED: STOP file exists')

    # Exit current positions (paper trades only).
    for ticker, p in list(s['positions'].items()):
        if ticker not in quotes:
            continue
        bid, _ = quotes[ticker]
        entry = D(p['entry'])
        held_s = (at - dt.datetime.fromisoformat(p['opened'])).total_seconds()
        if bid >= entry + D('0.04') or bid <= entry - D('0.03') or held_s >= MAX_AGE_S:
            proceeds = max(D('0'), bid - FEE_PER_SIDE)
            s['cash'] = str(D(s['cash']) + proceeds)
            pnl = proceeds - D(p['cost'])
            s['trades'].append({'ticker':ticker,'type':'CLOSE','at':at.isoformat(), 'exit_bid':str(bid),'pnl':str(pnl)})
            del s['positions'][ticker]
            print(f'PAPER CLOSE {ticker}: bid {bid}, net P/L {pnl}')

    cur_equity = equity(s, quotes)
    if cur_equity <= D(s['day_start_equity']) - MAX_DAILY_LOSS:
        s['halted'] = True
    # Update up to 2 prior price observations. No assumption that movement predicts true probability.
    candidate = []
    for ticker, (bid, ask) in quotes.items():
        mid = (bid + ask) / 2
        prev = [val(x) for x in s['history'].get(ticker, [])]
        prev = [x for x in prev if x is not None]
        if len(prev) >= 2:
            momentum = mid - prev[0]
            if momentum >= MIN_MOMENTUM and ask <= MAX_PRICE and ticker not in s['positions']:
                candidate.append((momentum, ticker, ask))
        s['history'][ticker] = [str(x) for x in (prev + [mid])[-2:]]
    # Prune history so stale tickers do not grow state forever.
    s['history'] = {t:s['history'][t] for t in quotes}
    candidate.sort(reverse=True)
    for _, ticker, ask in candidate:
        if s['halted'] or len(s['positions']) >= MAX_POSITIONS:
            break
        cost = ask + FEE_PER_SIDE
        if cost > MAX_TRADE or gross(s)+cost > MAX_GROSS or cost > D(s['cash']):
            continue
        # Ensure worst-case total loss capacity remains within today's daily limit.
        if (D(s['day_start_equity']) - cur_equity) + cost > MAX_DAILY_LOSS:
            continue
        s['cash'] = str(D(s['cash'])-cost)
        s['positions'][ticker] = {'entry':str(ask),'cost':str(cost),'opened':at.isoformat(), 'title':titles.get(ticker,ticker)}
        s['trades'].append({'ticker':ticker,'type':'OPEN','at':at.isoformat(),'ask':str(ask),'cost':str(cost)})
        print(f'PAPER OPEN YES {ticker}: ask {ask}, estimated cost incl buffer {cost}')
        cur_equity = equity(s, quotes)
    print(f'{at.isoformat()} markets_with_valid_quotes={len(quotes)} cash=${D(s["cash"]):.2f} '
          f'equity_est=${equity(s,quotes):.2f} open={len(s["positions"])} '
          f'gross=${gross(s):.2f} halted={s["halted"]}')
    return s


def fixture(mark):
    """Synthetic feed for offline functional testing; not fetched from Kalshi."""
    a = D('0.40') + D(mark)*D('0.02')
    b = D('0.55') + D(mark)*D('0.005')
    return [{'ticker':'FAKE-TEST-1','title':'Synthetic example only','yes_bid_dollars':str(a),'yes_ask_dollars':str(a+D('0.02'))},
            {'ticker':'FAKE-TEST-2','title':'Synthetic example only','yes_bid_dollars':str(b),'yes_ask_dollars':str(b+D('0.02'))}]


def main():
    p = argparse.ArgumentParser(description='Demo API scanner, LOCAL paper trades ONLY')
    p.add_argument('--once',action='store_true',help='one demo scan')
    p.add_argument('--loop',action='store_true',help='repeat scans')
    p.add_argument('--fixture',action='store_true',help='five deterministic offline synthetic cycles')
    p.add_argument('--reset-halt',action='store_true',help='manually acknowledge & clear halt only when STOP removed')
    p.add_argument('--pages',type=int,default=3,help='market pagination pages per cycle, 1..10')
    args = p.parse_args()
    if args.pages < 1 or args.pages > 10:
        p.error('--pages must be from 1 to 10')
    s = load_state()
    if args.reset_halt:
        if pathlib.Path('STOP').exists():
            p.error('Remove STOP file before reset')
        s['halted'] = False
        save_state(s)
        print('Halt reset; review open positions before resuming.')
        return
    if args.fixture:
        for i in range(5):
            run_cycle(s, fixture(i), now()+dt.timedelta(minutes=i))
        save_state(s)
        return
    if not (args.once or args.loop):
        p.error('Specify --once, --loop, --fixture or --reset-halt')
    print('DEMO read-only data; LOCAL PAPER trades; NO broker order calls; NO production integration')
    while True:
        try:
            markets = get_markets(args.pages)
            if not markets:
                raise RuntimeError('No markets returned: refusing to use old data')
            run_cycle(s, markets)
            save_state(s)
        except (OSError, ValueError, RuntimeError, TimeoutError) as exc:
            s['halted'] = True
            save_state(s)
            print('HALTED on data/network error:',repr(exc))
        if not args.loop:
            break
        time.sleep(60)

if __name__ == '__main__':
    main()
