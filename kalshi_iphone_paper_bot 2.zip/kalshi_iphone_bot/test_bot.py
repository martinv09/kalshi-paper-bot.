import datetime as dt
import pathlib
import tempfile
import unittest
from decimal import Decimal as D
import bot

class SafetyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old = bot.STATE_FILE
        bot.STATE_FILE = pathlib.Path(self.tmp.name)/'state.json'
    def tearDown(self):
        bot.STATE_FILE = self.old
        self.tmp.cleanup()
    def test_quote_rejects_missing_and_wide(self):
        self.assertIsNone(bot.quote({'yes_bid_dollars':'0.2'}))
        self.assertIsNone(bot.quote({'yes_bid_dollars':'0.2','yes_ask_dollars':'0.5'}))
    def test_fixture_strategy_entry(self):
        s=bot.initial()
        t=dt.datetime(2026,11,6,tzinfo=dt.timezone.utc)
        for i in range(4):
            bot.run_cycle(s,bot.fixture(i),t+dt.timedelta(minutes=i))
        self.assertTrue(len(s['trades'])>=1)
        self.assertLessEqual(bot.gross(s),bot.MAX_GROSS)
        self.assertTrue(all(D(p['cost']) <= bot.MAX_TRADE for p in s['positions'].values()))
    def test_halt_blocks_entries(self):
        s=bot.initial();s['halted']=True
        t=dt.datetime(2026,11,6,tzinfo=dt.timezone.utc)
        for i in range(4):bot.run_cycle(s,bot.fixture(i),t+dt.timedelta(minutes=i))
        self.assertFalse(s['positions'])
    def test_missing_held_quote_halts(self):
        s=bot.initial()
        s['positions']={'MISSING': {'entry':'0.50','cost':'0.51','opened':bot.now().isoformat()}}
        s['cash']='99.49'
        bot.run_cycle(s,bot.fixture(0))
        self.assertTrue(s['halted'])
    def test_daily_drawdown_halt(self):
        s=bot.initial();s['cash']='94.50'
        bot.run_cycle(s,bot.fixture(0))
        self.assertTrue(s['halted'])
    def test_state_roundtrip(self):
        s=bot.initial();bot.save_state(s)
        self.assertEqual(bot.load_state(),s)

if __name__=='__main__':unittest.main()
